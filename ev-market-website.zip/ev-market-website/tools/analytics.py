"""Data loading and aggregation for the EV market dashboard.

The dataset (data/ev_market.csv.gz) is a slimmed export of the Tableau extract:
200,000 vehicle records with the 11 columns the dashboards actually use.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

DATA_FILE = Path(__file__).parent / "data" / "ev_market.csv.gz"

# Filter dimension -> column in the dataset.
DIMENSIONS = {
    "year": "model_year",
    "region": "market_region",
    "category": "category",
    "battery": "battery_type",
    "country": "manufacturing_country",
    "manufacturer": "manufacturer",
}

TOP_N = 12  # bars shown in the manufacturer charts

# Approximate centre points (lon, lat) for the ten manufacturing countries.
COUNTRY_COORDS = {
    "China": (104.0, 35.0),
    "France": (2.5, 46.6),
    "Germany": (10.4, 51.2),
    "India": (78.9, 22.0),
    "Japan": (138.0, 37.0),
    "South Korea": (127.8, 36.5),
    "Sweden": (16.0, 62.5),
    "UK": (-2.0, 54.0),
    "USA": (-98.0, 39.5),
    "Vietnam": (106.0, 16.0),
}


class Store:
    """Holds the dataset in memory and answers filtered aggregate queries."""

    def __init__(self, path: Path = DATA_FILE):
        df = pd.read_csv(path)
        for col in ("model_name", "manufacturer", "category", "battery_type",
                    "market_region", "manufacturing_country"):
            df[col] = df[col].astype("category")
        df["model_year"] = df["model_year"].astype("int16")
        self.df = df
        self.options = {
            key: sorted(df[col].dropna().unique().tolist())
            for key, col in DIMENSIONS.items()
            if key != "manufacturer"
        }
        self.manufacturers = sorted(df["manufacturer"].cat.categories.tolist())
        self.total_sales = float(df["annual_sales_units"].sum())

    # ------------------------------------------------------------------ filters
    def clean_filters(self, raw: dict[str, list[str]]) -> dict[str, tuple]:
        """Keep only known dimensions and values; return hashable tuples."""
        out: dict[str, tuple] = {}
        for key, values in raw.items():
            if key not in DIMENSIONS:
                continue
            if key == "year":
                valid = {str(v) for v in self.options["year"]}
            elif key == "manufacturer":
                valid = set(self.manufacturers)
            else:
                valid = set(self.options[key])
            kept = tuple(sorted({v for v in values if v in valid}))
            if kept:
                out[key] = kept
        return out

    def _mask(self, filters: dict[str, tuple], skip: str | None = None) -> np.ndarray:
        mask = np.ones(len(self.df), dtype=bool)
        for key, values in filters.items():
            if key == skip:
                continue
            col = DIMENSIONS[key]
            if key == "year":
                mask &= self.df[col].isin([int(v) for v in values]).to_numpy()
            else:
                mask &= self.df[col].isin(values).to_numpy()
        return mask

    def _frame(self, filters, skip=None) -> pd.DataFrame:
        return self.df[self._mask(filters, skip)]

    # ------------------------------------------------------------- aggregations
    @staticmethod
    def _bars(series: pd.Series, selected: tuple, as_int: bool = True) -> list[dict]:
        series = series.dropna().sort_values(ascending=False)
        return [
            {
                "label": str(label),
                "value": int(round(v)) if as_int else round(float(v), 2),
                "selected": str(label) in selected,
            }
            for label, v in series.items()
        ]

    def _sales_by(self, frame: pd.DataFrame, col: str, selected: tuple) -> list[dict]:
        s = frame.groupby(col, observed=True)["annual_sales_units"].sum()
        s = s[s > 0]
        return self._bars(s, selected)

    def _top_with_selected(self, bars: list[dict], selected: tuple, n: int = TOP_N):
        """Top-n bars, plus any selected manufacturers that fell outside the top n."""
        top = bars[:n]
        shown = {b["label"] for b in top}
        top += [b for b in bars[n:] if b["selected"] and b["label"] not in shown]
        return top

    def dashboard(self, filters: dict[str, tuple]) -> dict:
        sel = lambda k: filters.get(k, ())  # noqa: E731
        everything = self._frame(filters)

        # KPI strip -- every filter applies
        n = len(everything)
        sales = float(everything["annual_sales_units"].sum()) if n else 0.0
        kpis = {
            "manufacturers": int(everything["manufacturer"].nunique()) if n else 0,
            "models": int(everything["model_name"].nunique()) if n else 0,
            "sales": sales,
            "rating": round(float(everything["customer_rating"].mean()), 2) if n else None,
            "range_km": round(float(everything["range_km"].mean()), 1) if n else None,
            "battery_kwh": round(float(everything["battery_capacity_kwh"].mean()), 1) if n else None,
            "records": n,
            "share_of_market": sales / self.total_sales if self.total_sales else 0.0,
        }

        # Each chart ignores the filter on its own dimension so the other bars
        # stay visible and the selected one can be highlighted.
        f_mfr = self._frame(filters, skip="manufacturer")
        mfr_sales = self._sales_by(f_mfr, "manufacturer", sel("manufacturer"))
        rating = (f_mfr.groupby("manufacturer", observed=True)["customer_rating"].mean()
                  .pipe(self._bars, sel("manufacturer"), False))

        f_cat = self._frame(filters, skip="category")
        range_by_cat = (f_cat.groupby("category", observed=True)["range_km"].mean()
                        .pipe(self._bars, sel("category"), False))

        f_cty = self._frame(filters, skip="country")
        countries = self._sales_by(f_cty, "manufacturing_country", sel("country"))
        for c in countries:
            lon, lat = COUNTRY_COORDS.get(c["label"], (0, 0))
            c["lon"], c["lat"] = lon, lat

        return {
            "filters": {k: list(v) for k, v in filters.items()},
            "kpis": kpis,
            "charts": {
                "manufacturer_sales": self._top_with_selected(mfr_sales, sel("manufacturer")),
                "customer_rating": self._top_with_selected(rating, sel("manufacturer")),
                "battery_sales": self._sales_by(self._frame(filters, skip="battery"),
                                                "battery_type", sel("battery")),
                "region_sales": self._sales_by(self._frame(filters, skip="region"),
                                               "market_region", sel("region")),
                "category_sales": self._sales_by(f_cat, "category", sel("category")),
                "category_range": range_by_cat,
                "countries": countries,
            },
        }

    # ------------------------------------------------------------------- story
    def story(self) -> dict:
        df = self.df
        total = self.total_sales

        def sales_by(col):
            return df.groupby(col, observed=True)["annual_sales_units"].sum().sort_values(ascending=False)

        by_year = df.groupby("model_year")["annual_sales_units"].sum()
        mix = (df.pivot_table(index="model_year", columns="battery_type", values="annual_sales_units",
                              aggfunc="sum", observed=True))
        mix_share = mix.div(mix.sum(axis=1), axis=0)
        swing = (mix_share.max() - mix_share.min()) * 100  # percentage-point range per chemistry

        mfr = sales_by("manufacturer")
        cat = sales_by("category")
        reg = sales_by("market_region")
        bat = sales_by("battery_type")
        cty = sales_by("manufacturing_country")
        rng = df.groupby("category", observed=True)["range_km"].mean().sort_values(ascending=False)
        mfr_rating = df.groupby("manufacturer", observed=True)["customer_rating"].mean().sort_values(ascending=False)

        def bars(s, digits=0):
            return [{"label": str(k), "value": round(float(v), digits) if digits else int(round(v))}
                    for k, v in s.items()]

        return {
            "totals": {
                "sales": total,
                "records": int(len(df)),
                "manufacturers": int(df["manufacturer"].nunique()),
                "models": int(df["model_name"].nunique()),
                "countries": int(df["manufacturing_country"].nunique()),
                "regions": int(df["market_region"].nunique()),
                "categories": int(df["category"].nunique()),
                "years": [int(df["model_year"].min()), int(df["model_year"].max())],
                "rating": float(df["customer_rating"].mean()),
                "range_km": float(df["range_km"].mean()),
                "battery_kwh": float(df["battery_capacity_kwh"].mean()),
            },
            "region": {"bars": bars(reg), "top": str(reg.index[0]), "low": str(reg.index[-1]),
                       "top_value": float(reg.iloc[0]), "low_value": float(reg.iloc[-1])},
            "category": {"bars": bars(cat), "top": str(cat.index[0]), "top_value": float(cat.iloc[0]),
                         "low": str(cat.index[-1]), "low_value": float(cat.iloc[-1]),
                         "top5_share": float(cat.iloc[:5].sum() / total),
                         "bottom3_share": float(cat.iloc[-3:].sum() / total)},
            "battery": {"bars": bars(bat),
                        "shares": {str(k): float(v / total) for k, v in bat.items()}},
            "battery_mix": {
                "years": [int(y) for y in mix_share.index],
                "series": {str(c): [round(float(x) * 100, 2) for x in mix_share[c]] for c in mix_share.columns},
                "swing_chem": str(swing.idxmax()),
                "swing_pp": float(swing.max()),
            },
            "year": {"bars": [{"label": str(int(y)), "value": int(v)} for y, v in by_year.items()],
                     "high": int(by_year.idxmax()), "low": int(by_year.idxmin()),
                     "high_value": float(by_year.max()), "low_value": float(by_year.min())},
            "range": {"bars": bars(rng, 1), "top": str(rng.index[0]), "top_value": float(rng.iloc[0]),
                      "low": str(rng.index[-1]), "low_value": float(rng.iloc[-1])},
            "manufacturer": {"bars": bars(mfr.head(TOP_N)), "top": str(mfr.index[0]),
                             "top_value": float(mfr.iloc[0]), "top_share": float(mfr.iloc[0] / total),
                             "top10_share": float(mfr.iloc[:10].sum() / total),
                             "median_share": float(mfr.median() / total)},
            "rating": {"top": str(mfr_rating.index[0]), "top_value": float(mfr_rating.iloc[0]),
                       "low": str(mfr_rating.index[-1]), "low_value": float(mfr_rating.iloc[-1]),
                       "bars": bars(mfr_rating.head(TOP_N), 2)},
            "country": {"bars": bars(cty), "top": str(cty.index[0]), "low": str(cty.index[-1]),
                        "top_value": float(cty.iloc[0]), "low_value": float(cty.iloc[-1]),
                        "top_share": float(cty.iloc[0] / total), "low_share": float(cty.iloc[-1] / total)},
        }


@lru_cache(maxsize=1)
def get_store() -> Store:
    return Store()


@lru_cache(maxsize=512)
def cached_dashboard(filter_items: tuple) -> dict:
    """Cache keyed by a hashable form of the cleaned filters."""
    return get_store().dashboard(dict(filter_items))


@lru_cache(maxsize=1)
def cached_story() -> dict:
    return get_store().story()
