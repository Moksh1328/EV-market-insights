"""Build the static site.

Reads source/ev_market.csv.gz and writes:
  assets/data/ev.bin.gz   all 200,000 rows, packed column by column (about 1.6 MB)
  assets/data/meta.json   lookup tables for the packed columns
  index.html, story.html  rendered from tools/templates/

Run from the repository root:   python tools/build_site.py
The generated files are committed, so GitHub Pages needs no build step.
"""
import gzip
import json
import sys
from pathlib import Path

import numpy as np
from jinja2 import Environment, FileSystemLoader, select_autoescape

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
from analytics import COUNTRY_COORDS, TOP_N, Store  # noqa: E402

NAN16 = 65535


def pack(store: Store) -> None:
    df = store.df
    n = len(df)
    cats = {
        "year": sorted(int(y) for y in df["model_year"].unique()),
        "region": store.options["region"],
        "category": store.options["category"],
        "battery": store.options["battery"],
        "country": store.options["country"],
        "manufacturer": store.manufacturers,
    }
    code = lambda col, vals: df[col].astype(str).map({v: i for i, v in enumerate(vals)}).to_numpy()  # noqa: E731

    sales = df["annual_sales_units"].fillna(0).round().astype("<u4").to_numpy()
    rating = np.where(df["customer_rating"].isna(), NAN16, (df["customer_rating"] * 100).round()).astype("<u2")
    rng = (df["range_km"] * 10).round().astype("<u2").to_numpy()
    kwh = (df["battery_capacity_kwh"] * 100).round().astype("<u2").to_numpy()
    model = df["model_name"].cat.codes.to_numpy().astype("<u2")
    u8 = lambda a: a.astype("u1")  # noqa: E731
    cols = [
        sales, rating, rng, kwh, model,                                    # 4 + 2 + 2 + 2 + 2 bytes per row
        u8(df["model_year"].map({y: i for i, y in enumerate(cats["year"])}).to_numpy()),
        u8(code("market_region", cats["region"])),
        u8(code("category", cats["category"])),
        u8(code("battery_type", cats["battery"])),
        u8(code("manufacturing_country", cats["country"])),
        u8(code("manufacturer", cats["manufacturer"])),
    ]
    blob = b"".join(c.tobytes() for c in cols)
    out = ROOT / "assets" / "data"
    out.mkdir(parents=True, exist_ok=True)
    (out / "ev.bin.gz").write_bytes(gzip.compress(blob, 9, mtime=0))
    meta = {
        "rows": n,
        "models": int(df["model_name"].nunique()),
        "nan16": NAN16,
        "top_n": TOP_N,
        "dims": cats,
        "coords": {k: list(v) for k, v in COUNTRY_COORDS.items()},
    }
    (out / "meta.json").write_text(json.dumps(meta, separators=(",", ":")))
    size = (out / "ev.bin.gz").stat().st_size / 1e6
    print(f"packed {n:,} rows -> assets/data/ev.bin.gz ({size:.1f} MB)")


def render(store: Store) -> None:
    env = Environment(loader=FileSystemLoader(ROOT / "tools" / "templates"),
                      autoescape=select_autoescape(["html"]))

    def compact(value, digits=1):
        v = float(value)
        if abs(v) >= 1e9: return f"{v / 1e9:.2f}B"
        if abs(v) >= 1e6: return f"{v / 1e6:.{digits}f}M"
        if abs(v) >= 1e3: return f"{v / 1e3:.{digits}f}K"
        return f"{v:.0f}"

    env.filters["compact"] = compact
    env.filters["pct"] = lambda v, digits=1: f"{float(v) * 100:.{digits}f}%"

    pages = {
        "index.html": ("dashboard.html", dict(page="dashboard", options=store.options,
                                              total_sales=store.total_sales, record_count=len(store.df))),
        "story.html": ("story.html", dict(page="story", s=store.story())),
    }
    for out, (tpl, ctx) in pages.items():
        (ROOT / out).write_text(env.get_template(tpl).render(**ctx), encoding="utf-8")
        print("wrote", out)


if __name__ == "__main__":
    store = Store(ROOT / "source" / "ev_market.csv.gz")
    pack(store)
    render(store)
