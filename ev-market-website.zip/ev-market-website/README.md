# EV Market Performance

A plain website (HTML, CSS and JavaScript, no server needed) built from two Tableau workbooks of electric-vehicle market data. It can be hosted for free on GitHub Pages.

![Dashboard](docs/dashboard.png)

## What's in it

- **`index.html` is the interactive dashboard.** Click any bar or map bubble to filter every chart, click again to clear, or use the dropdowns. It shows six KPIs, a battery gauge for how much of the market your filters cover, and seven charts (manufacturing-country map, sales by region, battery type, manufacturer and category, rating by manufacturer, range by category). Filters live in the URL, so any view can be shared as a link.
- **`story.html` is a guided market story.** The text and numbers are generated from the data.

![Filtered view](docs/dashboard-filtered.png)

All 200,000 records are downloaded once (2.3 MB) and filtered in the browser, so the dashboard works without a backend and each click responds in a few milliseconds.

## Publish on GitHub Pages

1. Create a new repository on GitHub and upload everything in this folder (keep the folder structure).
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick the `main` branch and the `/ (root)` folder, then save.
4. After a minute your site is live at `https://<your-username>.github.io/<repository-name>/`.

Any other static host (Netlify, Cloudflare Pages, Vercel, an S3 bucket) works the same way: just serve this folder.

## Preview locally

Browsers block data downloads from `file://`, so don't double-click `index.html`. Serve the folder instead:

```bash
python -m http.server 8000
```

Then open http://localhost:8000.

## Project layout

```
index.html, story.html   the two pages (generated, committed)
assets/css, assets/js    styles and scripts; engine.js is the in-browser query engine
assets/vendor            Chart.js, D3, topojson-client (bundled, no CDN)
assets/fonts             Bricolage Grotesque and IBM Plex Sans
assets/data              ev.bin.gz + meta.json (packed dataset), world map
source/                  ev_market.csv.gz, the slimmed source data
tools/                   build script and page templates
```

## Changing the content

`index.html` and `story.html` are generated from `tools/templates/`. After editing a template, or replacing `source/ev_market.csv.gz`, rebuild:

```bash
pip install -r tools/requirements.txt
python tools/build_site.py
```

CSS and JavaScript in `assets/` can be edited directly with no build step.

## About the data

The source table is named `ev_market_train`. Totals are almost identical across regions, years and countries, which suggests a generated or simulated dataset rather than real registrations. Treat the findings as a demonstration of the analysis, not as market facts.

## Credits

Chart.js (MIT), D3 and topojson-client (ISC), world-atlas (ISC, Natural Earth data), Bricolage Grotesque and IBM Plex Sans (SIL OFL). See `assets/vendor/LICENSES.md`.
