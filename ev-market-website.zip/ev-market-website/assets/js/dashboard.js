/* Dashboard controller: holds filter state, queries the in-browser engine, redraws everything. */
(function () {
  const { fmt, fillTable, makeBars, setBars } = EV;
  const DIMS = ["year", "region", "category", "battery", "country", "manufacturer"];
  const LABELS = { year: "Year", region: "Region", category: "Category", battery: "Battery", country: "Country", manufacturer: "Manufacturer" };

  const state = {};   // dim -> Set of selected values
  DIMS.forEach((d) => (state[d] = new Set()));
  let seq = 0, totalSales = 0;

  const $ = (id) => document.getElementById(id);
  const selects = [...document.querySelectorAll("#filters select")];

  /* ---------- charts ---------- */
  const pick = (dim) => (label) => toggle(dim, label);
  const charts = {
    mfr:    makeBars($("c-mfr"),    { format: fmt.compact, unit: "units sold", onPick: pick("manufacturer") }),
    rating: makeBars($("c-rating"), { format: fmt.two, unit: "average rating", max: 5, onPick: pick("manufacturer") }),
    battery:makeBars($("c-battery"),{ format: fmt.compact, unit: "units sold", onPick: pick("battery") }),
    region: makeBars($("c-region"), { format: fmt.compact, unit: "units sold", onPick: pick("region") }),
    cat:    makeBars($("c-cat"),    { format: fmt.compact, unit: "units sold", onPick: pick("category") }),
    range:  makeBars($("c-range"),  { format: fmt.one, unit: "km average range", onPick: pick("category") }),
  };
  EVMap.init("#map", pick("country"));

  /* ---------- state <-> URL ---------- */
  function toQuery() {
    const q = new URLSearchParams();
    DIMS.forEach((d) => [...state[d]].sort().forEach((v) => q.append(d, v)));
    return q;
  }
  function toFilters() {
    const f = {};
    DIMS.forEach((d) => { if (state[d].size) f[d] = [...state[d]]; });
    return f;
  }
  function toggle(dim, value) {
    state[dim].has(value) ? state[dim].delete(value) : state[dim].add(value);
    load();
  }
  function clearAll() { DIMS.forEach((d) => state[d].clear()); load(); }

  selects.forEach((sel) => sel.addEventListener("change", () => {
    const dim = sel.dataset.dim;
    state[dim].clear();
    if (sel.value && sel.value !== "__multi") state[dim].add(sel.value);
    load();
  }));
  $("reset").addEventListener("click", clearAll);

  /* ---------- rendering ---------- */
  function syncControls() {
    selects.forEach((sel) => {
      const dim = sel.dataset.dim, set = state[dim];
      sel.querySelector('[data-multi]')?.remove();
      if (set.size > 1) {
        const o = new Option(`${set.size} selected`, "__multi"); o.dataset.multi = "1";
        sel.add(o, 1); sel.value = "__multi";
      } else sel.value = set.size === 1 ? [...set][0] : "";
    });
    const chips = $("chips"); chips.replaceChildren();
    let n = 0;
    DIMS.forEach((d) => [...state[d]].sort().forEach((v) => {
      n++;
      const b = document.createElement("button");
      b.type = "button"; b.className = "chip";
      b.setAttribute("aria-label", `Remove filter ${LABELS[d]}: ${v}`);
      b.append(`${LABELS[d]}: ${v}`);
      const x = document.createElement("span"); x.className = "chip-x"; x.setAttribute("aria-hidden", "true"); x.textContent = "×";
      b.append(x);
      b.addEventListener("click", () => toggle(d, v));
      chips.append(b);
    }));
    if (!n) {
      const hint = document.createElement("span"); hint.className = "chips-hint";
      hint.textContent = "No filters applied. Showing the whole market."; chips.append(hint);
    }
    $("reset").disabled = n === 0;
  }

  function renderSummary(k, totalAll) {
    $("k-manufacturers").textContent = fmt.int(k.manufacturers);
    $("k-models").textContent = fmt.int(k.models);
    $("k-sales").textContent = fmt.compact(k.sales);
    const withUnit = (id, val, unit) => { const el = $(id); el.textContent = val; if (unit) { const u = document.createElement("span"); u.className = "unit"; u.textContent = unit; el.append(u); } };
    withUnit("k-rating", k.rating == null ? "–" : fmt.two(k.rating), k.rating == null ? "" : "/ 5");
    withUnit("k-range", k.range_km == null ? "–" : fmt.one(k.range_km), k.range_km == null ? "" : "km");
    withUnit("k-battery", k.battery_kwh == null ? "–" : fmt.one(k.battery_kwh), k.battery_kwh == null ? "" : "kWh");

    $("gauge-pct").textContent = fmt.pct(k.share_of_market);
    $("gauge-text").textContent =
      k.records === 0 ? "No units match your filters"
      : k.share_of_market >= 0.9999 ? `Whole market in view: ${fmt.compact(k.sales)} units`
      : `${fmt.compact(k.sales)} of ${fmt.compact(totalAll)} units match your filters`;
    const cells = [...document.querySelectorAll("#cells .cell")];
    const on = k.share_of_market > 0 ? Math.max(1, Math.round(k.share_of_market * cells.length)) : 0;
    cells.forEach((c, i) => c.classList.toggle("on", i < on));
    $("empty").classList.toggle("show", k.records === 0);
    $("summary").setAttribute("aria-busy", "false");
  }

  function render(data) {
    const c = data.charts, k = data.kpis;
    renderSummary(k, totalSales);
    setBars(charts.mfr,    c.manufacturer_sales, { wrapper: $("p-mfr") });
    setBars(charts.rating, c.customer_rating,    { wrapper: $("p-rating") });
    setBars(charts.battery,c.battery_sales,      { wrapper: $("p-battery"), barHeight: 34 });
    setBars(charts.region, c.region_sales,       { wrapper: $("p-region"),  barHeight: 31 });
    setBars(charts.cat,    c.category_sales,     { wrapper: $("p-cat") });
    setBars(charts.range,  c.category_range,     { wrapper: $("p-range") });
    EVMap.render(c.countries);

    const tab = (id, cap, head, rows) => fillTable($(id), cap, head, rows);
    tab("t-mfr", "Units sold by manufacturer", ["Manufacturer", "Units"], c.manufacturer_sales.map((r) => [r.label, fmt.int(r.value)]));
    tab("t-rating", "Average rating by manufacturer", ["Manufacturer", "Rating"], c.customer_rating.map((r) => [r.label, fmt.two(r.value)]));
    tab("t-battery", "Units sold by battery type", ["Battery", "Units"], c.battery_sales.map((r) => [r.label, fmt.int(r.value)]));
    tab("t-region", "Units sold by region", ["Region", "Units"], c.region_sales.map((r) => [r.label, fmt.int(r.value)]));
    tab("t-cat", "Units sold by category", ["Category", "Units"], c.category_sales.map((r) => [r.label, fmt.int(r.value)]));
    tab("t-range", "Average range by category", ["Category", "Kilometres"], c.category_range.map((r) => [r.label, fmt.one(r.value)]));
    tab("t-countries", "Units sold by manufacturing country", ["Country", "Units"], c.countries.map((r) => [r.label, fmt.int(r.value)]));
  }

  async function load() {
    const mine = ++seq;
    const q = toQuery().toString();
    history.replaceState(null, "", q ? `?${q}` : location.pathname);
    syncControls();
    try {
      const data = await EVEngine.query(toFilters());
      if (mine !== seq) return;                        // a newer request superseded this one
      // The server drops values it doesn't recognise; adopt its cleaned filters.
      DIMS.forEach((d) => { state[d] = new Set(data.filters[d] || []); });
      const cleaned = toQuery().toString();
      history.replaceState(null, "", cleaned ? `?${cleaned}` : location.pathname);
      syncControls();
      render(data);
    } catch (err) {
      $("empty").textContent = "Couldn't load the data. If you opened this file directly, serve the folder with a local web server (see the README).";
      $("empty").classList.add("show");
      console.error(err);
    }
  }

  /* ---------- boot ---------- */
  const params = new URLSearchParams(location.search);
  DIMS.forEach((d) => params.getAll(d).forEach((v) => state[d].add(v)));
  // Canvas text doesn't trigger font loading, so request the faces before the first draw.
  const fontsReady = document.fonts
    ? Promise.all([
        document.fonts.load('500 12px "IBM Plex Sans"'),
        document.fonts.load('700 19px "Bricolage Grotesque"'),
      ]).catch(() => {})
    : Promise.resolve();
  $("gauge-text").textContent = "Loading 200,000 records…";
  EVEngine.totalSales().then((t) => { totalSales = t; });
  fontsReady.then(() => EVEngine.totalSales()).then((t) => { totalSales = t; }).then(load);
})();
