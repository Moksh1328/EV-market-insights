/* Story page: static charts drawn from the aggregates embedded by the server. */
(function () {
  const S = window.__STORY__;
  const { C, fmt, makeBars, setBars } = EV;
  const $ = (id) => document.getElementById(id);
  const rows = (bars) => bars.map((b) => ({ label: b.label, value: b.value, selected: false }));

  function draw() {
    setBars(makeBars($("c-region"), { format: fmt.compact, unit: "units sold" }), rows(S.region.bars), { wrapper: $("c-region").parentElement, barHeight: 33 });
    setBars(makeBars($("c-cat"), { format: fmt.compact, unit: "units sold" }), rows(S.category.bars), { wrapper: $("p-cat") });
    setBars(makeBars($("c-range"), { format: fmt.one, unit: "km average range" }), rows(S.range.bars), { wrapper: $("p-range") });
    setBars(makeBars($("c-mfr"), { format: fmt.compact, unit: "units sold" }), rows(S.manufacturer.bars), { wrapper: $("p-mfr") });

    // Sales by year: vertical columns starting at zero so the evenness is visible.
    const year = makeBars($("c-year"), { format: fmt.compact, unit: "units sold", horizontal: false });
    setBars(year, rows(S.year.bars));

    // Battery mix by year: 100% stacked columns.
    const colours = { NMC: C.teal, LFP: C.ink, NCA: "#7d9ca0", "Sodium-Ion": C.volt, "Solid-State": "#e0693f" };
    new Chart($("c-mix"), {
      type: "bar",
      data: {
        labels: S.battery_mix.years.map(String),
        datasets: Object.entries(S.battery_mix.series).map(([name, data]) => ({
          label: name, data, backgroundColor: colours[name] || C.slate, borderWidth: 1.5, borderColor: "#fff", maxBarThickness: 46,
        })),
      },
      options: {
        responsive: true, maintainAspectRatio: false, animation: { duration: 280 },
        scales: {
          x: { stacked: true, grid: { display: false }, border: { display: false } },
          y: { stacked: true, min: 0, max: 100, ticks: { callback: (v) => v + "%" }, grid: { color: C.line }, border: { display: false } },
        },
        plugins: {
          legend: { position: "bottom", labels: { boxWidth: 12, boxHeight: 12, usePointStyle: false, padding: 16 } },
          tooltip: { backgroundColor: C.ink, padding: 10, callbacks: { label: (c) => `${c.dataset.label}: ${c.parsed.y.toFixed(1)}%` } },
        },
      },
    });
  }

  const ready = document.fonts
    ? Promise.all([document.fonts.load('500 12px "IBM Plex Sans"')]).catch(() => {})
    : Promise.resolve();
  ready.then(draw);
})();
