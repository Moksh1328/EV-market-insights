/* In-browser query engine. Replaces the server API: loads the packed dataset once,
   then answers every filter change with a single pass over the 200,000 rows. */
window.EVEngine = (function () {
  const DIMS = ["year", "region", "category", "battery", "country", "manufacturer"];
  const BIT = Object.fromEntries(DIMS.map((d, i) => [d, 1 << i]));

  async function gunzip(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`${url}: ${res.status}`);
    if (typeof DecompressionStream === "undefined") throw new Error("This browser is too old (no DecompressionStream).");
    const stream = res.body.pipeThrough(new DecompressionStream("gzip"));
    return new Response(stream).arrayBuffer();
  }

  const ready = Promise.all([
    fetch("assets/data/meta.json").then((r) => r.json()),
    gunzip("assets/data/ev.bin.gz"),
  ]).then(([meta, buf]) => {
    const n = meta.rows;
    // Column layout must match tools/build_site.py
    const col = {
      sales: new Uint32Array(buf, 0, n),
      rating: new Uint16Array(buf, 4 * n, n),
      range: new Uint16Array(buf, 6 * n, n),
      kwh: new Uint16Array(buf, 8 * n, n),
      model: new Uint16Array(buf, 10 * n, n),
    };
    DIMS.forEach((d, i) => { col[d] = new Uint8Array(buf, 12 * n + i * n, n); });
    let total = 0;
    for (let i = 0; i < n; i++) total += col.sales[i];
    return { meta, col, total };
  });

  const round = (v, d) => { const f = 10 ** d; return Math.round(v * f) / f; };

  function bars(labels, values, selected, digits) {
    const out = [];
    values.forEach((v, i) => {
      if (v == null || Number.isNaN(v)) return;
      out.push({ label: labels[i], raw: v, value: digits == null ? Math.round(v) : round(v, digits), selected: selected.has(String(labels[i])) });
    });
    // Rank on the unrounded value so near-ties order the same way they would in pandas.
    return out.sort((a, b) => b.raw - a.raw || (a.label < b.label ? -1 : 1)).map(({ raw, ...rest }) => rest);
  }
  const topWithSelected = (list, n) => {
    const top = list.slice(0, n), shown = new Set(top.map((b) => b.label));
    return top.concat(list.slice(n).filter((b) => b.selected && !shown.has(b.label)));
  };

  async function query(raw) {
    const { meta, col, total } = await ready;
    const n = meta.rows, D = meta.dims;

    // Keep only known values, like the server did.
    const filters = {}, masks = [], chosen = {};
    DIMS.forEach((d) => {
      const vals = D[d].map(String), want = new Set((raw[d] || []).map(String));
      const mask = new Uint8Array(vals.length);
      let hit = false;
      vals.forEach((v, i) => { if (want.has(v)) { mask[i] = 1; hit = true; } });
      if (hit) filters[d] = vals.filter((v) => want.has(v)).sort(); else mask.fill(1);
      chosen[d] = new Set(filters[d] || []);
      masks.push(mask);
    });
    const [m0, m1, m2, m3, m4, m5] = masks;
    const { year, region, category, battery, country, manufacturer, sales, rating, range, kwh, model } = col;
    const NAN = meta.nan16;

    // KPI accumulators (all filters) ...
    let k_n = 0, k_sales = 0, k_rs = 0, k_rc = 0, k_range = 0, k_kwh = 0;
    const seenM = new Uint8Array(D.manufacturer.length), seenModel = new Uint8Array(meta.models + 1);
    // ... and one set per chart, each ignoring its own dimension's filter.
    const mS = new Float64Array(D.manufacturer.length), mRs = new Float64Array(D.manufacturer.length), mRc = new Uint32Array(D.manufacturer.length);
    const bS = new Float64Array(D.battery.length), gS = new Float64Array(D.region.length), kS = new Float64Array(D.country.length);
    const cS = new Float64Array(D.category.length), cR = new Float64Array(D.category.length), cN = new Uint32Array(D.category.length);

    for (let i = 0; i < n; i++) {
      let f = 0;
      if (!m0[year[i]]) f |= 1;
      if (!m1[region[i]]) f |= 2;
      if (!m2[category[i]]) f |= 4;
      if (!m3[battery[i]]) f |= 8;
      if (!m4[country[i]]) f |= 16;
      if (!m5[manufacturer[i]]) f |= 32;
      const s = sales[i], r = rating[i];
      if (f === 0) {
        k_n++; k_sales += s; k_range += range[i]; k_kwh += kwh[i];
        if (r !== NAN) { k_rs += r; k_rc++; }
        seenM[manufacturer[i]] = 1; seenModel[model[i]] = 1;
      }
      if ((f & ~32) === 0) { const m = manufacturer[i]; mS[m] += s; if (r !== NAN) { mRs[m] += r; mRc[m]++; } }
      if ((f & ~8) === 0) bS[battery[i]] += s;
      if ((f & ~2) === 0) gS[region[i]] += s;
      if ((f & ~4) === 0) { const c = category[i]; cS[c] += s; cR[c] += range[i]; cN[c]++; }
      if ((f & ~16) === 0) kS[country[i]] += s;
    }

    const count = (a) => a.reduce((x, y) => x + y, 0);
    const salesBars = (labels, vals, dim) => bars(labels, Array.from(vals, (v) => (v > 0 ? v : null)), chosen[dim]);
    const mfrRating = D.manufacturer.map((_, i) => (mRc[i] ? mRs[i] / mRc[i] / 100 : null));
    const catRange = D.category.map((_, i) => (cN[i] ? cR[i] / cN[i] / 10 : null));

    const countries = salesBars(D.country, kS, "country").map((c) => {
      const [lon, lat] = meta.coords[c.label] || [0, 0];
      return { ...c, lon, lat };
    });

    return {
      filters,
      kpis: {
        manufacturers: count(seenM), models: count(seenModel), sales: k_sales,
        rating: k_rc ? round(k_rs / k_rc / 100, 2) : null,
        range_km: k_n ? round(k_range / k_n / 10, 1) : null,
        battery_kwh: k_n ? round(k_kwh / k_n / 100, 1) : null,
        records: k_n, share_of_market: total ? k_sales / total : 0,
      },
      charts: {
        manufacturer_sales: topWithSelected(salesBars(D.manufacturer, mS, "manufacturer"), meta.top_n),
        customer_rating: topWithSelected(bars(D.manufacturer, mfrRating, chosen.manufacturer, 2), meta.top_n),
        battery_sales: salesBars(D.battery, bS, "battery"),
        region_sales: salesBars(D.region, gS, "region"),
        category_sales: salesBars(D.category, cS, "category"),
        category_range: bars(D.category, catRange, chosen.category, 2),
        countries,
      },
    };
  }

  return { query, totalSales: () => ready.then((r) => r.total) };
})();
