/* Shared helpers: number formatting, chart defaults, accessible data tables. */
window.EV = (function () {
  const C = {
    ink: "#10272b", soft: "#4a6266", teal: "#0c8f7e", deep: "#075e53",
    slate: "#b4c6c8", volt: "#f2ce3c", line: "#d3dfe0",
  };

  const fmt = {
    compact(v) {
      if (v == null) return "–";
      const a = Math.abs(v);
      if (a >= 1e9) return (v / 1e9).toFixed(2) + "B";
      if (a >= 1e6) return (v / 1e6).toFixed(1) + "M";
      if (a >= 1e3) return (v / 1e3).toFixed(1) + "K";
      return String(Math.round(v));
    },
    int: (v) => (v == null ? "–" : Math.round(v).toLocaleString("en-US")),
    one: (v) => (v == null ? "–" : v.toFixed(1)),
    two: (v) => (v == null ? "–" : v.toFixed(2)),
    pct(share) {
      if (share === 0) return "0%";
      if (share < 0.001) return "<0.1%";
      return (share * 100).toFixed(share < 0.1 ? 1 : 0) + "%";
    },
  };

  // Draws the value at the end of each bar.
  const valueLabels = {
    id: "valueLabels",
    afterDatasetsDraw(chart, _args, opts) {
      if (!opts || !opts.format) return;
      const { ctx } = chart;
      const horizontal = chart.options.indexAxis === "y";
      ctx.save();
      ctx.font = '500 12px "IBM Plex Sans", "Segoe UI", sans-serif';
      ctx.fillStyle = C.ink;
      chart.getDatasetMeta(0).data.forEach((bar, i) => {
        const v = chart.data.datasets[0].data[i];
        if (v == null) return;
        if (horizontal) { ctx.textAlign = "left"; ctx.textBaseline = "middle"; ctx.fillText(opts.format(v), bar.x + 6, bar.y); }
        else { ctx.textAlign = "center"; ctx.textBaseline = "bottom"; ctx.fillText(opts.format(v), bar.x, bar.y - 4); }
      });
      ctx.restore();
    },
  };

  Chart.defaults.font.family = '"IBM Plex Sans", "Segoe UI", sans-serif';
  Chart.defaults.font.size = 12;
  Chart.defaults.color = C.ink;

  /** Horizontal (default) or vertical single-series bar chart. */
  function makeBars(canvas, { format, unit, max, horizontal = true, onPick }) {
    return new Chart(canvas, {
      type: "bar",
      plugins: [valueLabels],
      data: { labels: [], datasets: [{ data: [], backgroundColor: [], borderRadius: 3, maxBarThickness: 22, barPercentage: 0.82, categoryPercentage: 0.9 }] },
      options: {
        indexAxis: horizontal ? "y" : "x",
        responsive: true, maintainAspectRatio: false,
        animation: { duration: 280 },
        layout: { padding: horizontal ? { right: 58 } : { top: 20 } },
        scales: {
          [horizontal ? "x" : "y"]: { display: false, beginAtZero: true, max, grid: { display: false } },
          [horizontal ? "y" : "x"]: { grid: { display: false }, border: { display: false }, ticks: { color: C.ink, autoSkip: false, padding: 6 } },
        },
        plugins: {
          legend: { display: false },
          valueLabels: { format },
          tooltip: {
            backgroundColor: C.ink, padding: 10, displayColors: false, titleFont: { weight: "600" },
            callbacks: { label: (ctx) => `${format(ctx.parsed[horizontal ? "x" : "y"])} ${unit}` },
          },
        },
        onClick: onPick ? (_e, els, chart) => { if (els.length) onPick(chart.data.labels[els[0].index]); } : undefined,
        onHover: onPick ? (e, els) => { e.native.target.style.cursor = els.length ? "pointer" : "default"; } : undefined,
      },
    });
  }

  /** Push new bars into a chart. `rows` = [{label, value, selected}] */
  function setBars(chart, rows, { barHeight = 30, pad = 24, wrapper } = {}) {
    const anySelected = rows.some((r) => r.selected);
    const ds = chart.data.datasets[0];
    chart.data.labels = rows.map((r) => r.label);
    ds.data = rows.map((r) => r.value);
    ds.backgroundColor = rows.map((r) => (anySelected ? (r.selected ? C.ink : C.slate) : C.teal));
    if (wrapper) wrapper.style.height = Math.max(rows.length, 3) * barHeight + pad + "px";
    chart.update();
  }

  /** Mirror chart data into a visually hidden table for screen readers. */
  function fillTable(table, caption, header, rows) {
    table.replaceChildren();
    const cap = table.createCaption(); cap.textContent = caption;
    const head = table.createTHead().insertRow();
    header.forEach((h) => { const th = document.createElement("th"); th.textContent = h; head.appendChild(th); });
    const body = table.createTBody();
    rows.forEach((r) => { const tr = body.insertRow(); r.forEach((c) => { tr.insertCell().textContent = c; }); });
  }

  return { C, fmt, makeBars, setBars, fillTable };
})();
