/* Bubble map of units sold by manufacturing country (D3 + TopoJSON, no tile server). */
window.EVMap = (function () {
  const { C, fmt } = EV;
  const W = 960;
  let svg, projection, path, land, h = 0, onPick = null, ready;

  function init(selector, pick) {
    onPick = pick;
    svg = d3.select(selector);
    ready = fetch("assets/data/countries-110m.json").then((r) => r.json()).then((topo) => {
      const countries = topojson.feature(topo, topo.objects.countries);
      land = { type: "FeatureCollection", features: countries.features.filter((f) => f.id !== "010") }; // drop Antarctica
      projection = d3.geoNaturalEarth1().fitWidth(W - 16, land);
      path = d3.geoPath(projection);
      const [[, y0], [, y1]] = path.bounds(land);
      h = Math.ceil(y1 - y0) + 24;
      projection.translate([projection.translate()[0] + 8, projection.translate()[1] - y0 + 12]);
      svg.attr("viewBox", `0 0 ${W} ${h}`);
      svg.append("g").attr("class", "land-layer").selectAll("path").data(land.features).join("path")
        .attr("class", "land").attr("d", path);
      svg.append("g").attr("class", "lead-layer");
      svg.append("g").attr("class", "bubble-layer");
      svg.append("g").attr("class", "label-layer");
    });
    return ready;
  }

  async function render(rows) {
    await ready;
    const anySel = rows.some((r) => r.selected);
    const max = d3.max(rows, (r) => r.value) || 1;
    const radius = d3.scaleSqrt().domain([0, max]).range([0, 26]);

    const nodes = rows.map((r) => {
      const [x, y] = projection([r.lon, r.lat]);
      return { ...r, ax: x, ay: y, x, y, r: Math.max(radius(r.value), 3) };
    });
    // Nudge overlapping bubbles apart (Europe is crowded), keeping them near their true location.
    const sim = d3.forceSimulation(nodes)
      .force("x", d3.forceX((d) => d.ax).strength(0.9))
      .force("y", d3.forceY((d) => d.ay).strength(0.9))
      .force("collide", d3.forceCollide((d) => d.r + 9))
      .stop();
    for (let i = 0; i < 200; i++) sim.tick();

    const fill = (d) => (anySel ? (d.selected ? C.ink : C.slate) : C.teal);

    svg.select(".lead-layer").selectAll("g").data(nodes.filter((d) => Math.hypot(d.x - d.ax, d.y - d.ay) > 4), (d) => d.label)
      .join((enter) => { const g = enter.append("g"); g.append("line").attr("class", "lead"); g.append("circle").attr("class", "lead-dot").attr("r", 2.2); return g; })
      .each(function (d) {
        const g = d3.select(this);
        g.select("line").attr("x1", d.ax).attr("y1", d.ay).attr("x2", d.x).attr("y2", d.y).style("stroke", "#4a6266").style("stroke-width", 0.8);
        g.select("circle").attr("cx", d.ax).attr("cy", d.ay);
      });

    const bubbles = svg.select(".bubble-layer").selectAll("circle").data(nodes, (d) => d.label);
    bubbles.join(
      (enter) => enter.append("circle").attr("class", "bubble").attr("r", 0).attr("cx", (d) => d.x).attr("cy", (d) => d.y)
        .on("click", (_e, d) => onPick(d.label)).call((s) => s.append("title")),
      (update) => update,
    )
      .attr("cx", (d) => d.x).attr("cy", (d) => d.y)
      .attr("r", (d) => d.r)
      .attr("fill", fill).attr("fill-opacity", 0.88)
      .select("title").text((d) => `${d.label}: ${fmt.compact(d.value)} units`);
    bubbles.exit().remove();

    svg.select(".label-layer").selectAll("text").data(nodes, (d) => d.label)
      .join("text").attr("text-anchor", "middle")
      .attr("x", (d) => d.x).attr("y", (d) => d.y + d.r + 13)
      .text((d) => d.label);
  }

  return { init, render };
})();
