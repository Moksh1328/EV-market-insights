"""Rebuild data/ev_market.csv.gz from a Tableau packaged workbook (.twbx).

The workbooks store their data as a Hyper extract. This script pulls out the
11 columns the site uses and writes them as a compressed CSV (~4 MB instead of
the ~19 MB extract).

    pip install -r requirements-dev.txt
    python scripts/build_data.py path/to/EV_Market_Performance_Interactive_Refreshed.twbx
"""
import sys
import tempfile
import zipfile
from pathlib import Path

import pandas as pd
from tableauhyperapi import Connection, HyperProcess, Telemetry

COLUMNS = [
    "model_name", "manufacturer", "category", "battery_type", "market_region",
    "manufacturing_country", "model_year", "annual_sales_units", "customer_rating",
    "range_km", "battery_capacity_kwh",
]
OUT = Path(__file__).resolve().parent.parent / "data" / "ev_market.csv.gz"


def main(twbx: str) -> None:
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(twbx) as z:
        hypers = [n for n in z.namelist() if n.endswith(".hyper")]
        if not hypers:
            sys.exit("No .hyper extract found inside the workbook.")
        z.extract(hypers[0], tmp)
        hyper_path = Path(tmp) / hypers[0]
        cols = ", ".join(f'"{c}"' for c in COLUMNS)
        with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
            with Connection(hp.endpoint, str(hyper_path)) as conn:
                result = conn.execute_query(f'SELECT {cols} FROM "Extract"."Extract"')
                df = pd.DataFrame([list(r) for r in result], columns=COLUMNS)
    df.to_csv(OUT, index=False, compression="gzip")
    print(f"Wrote {len(df):,} rows to {OUT} ({OUT.stat().st_size / 1e6:.1f} MB)")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
