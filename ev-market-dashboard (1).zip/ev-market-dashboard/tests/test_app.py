import pytest

from app import app


@pytest.fixture(scope="module")
def client():
    return app.test_client()


def test_pages_render(client):
    for path in ("/", "/story"):
        assert client.get(path).status_code == 200


def test_health(client):
    assert client.get("/healthz").get_json() == {"status": "ok"}


def test_kpis_match_the_tableau_dashboard(client):
    k = client.get("/api/dashboard").get_json()["kpis"]
    assert k["manufacturers"] == 200
    assert k["models"] == 17980
    assert round(k["sales"] / 1e9, 2) == 1.55
    assert k["rating"] == 4.09
    assert k["range_km"] == 324.5
    assert k["battery_kwh"] == 78.2
    assert k["share_of_market"] == 1.0


def test_filters_narrow_results(client):
    whole = client.get("/api/dashboard").get_json()["kpis"]["sales"]
    europe = client.get("/api/dashboard?region=Europe").get_json()["kpis"]["sales"]
    both = client.get("/api/dashboard?region=Europe&battery=LFP").get_json()["kpis"]["sales"]
    assert both < europe < whole


def test_multi_select_adds_up(client):
    a = client.get("/api/dashboard?year=2020").get_json()["kpis"]["sales"]
    b = client.get("/api/dashboard?year=2021").get_json()["kpis"]["sales"]
    ab = client.get("/api/dashboard?year=2020&year=2021").get_json()["kpis"]["sales"]
    assert ab == pytest.approx(a + b)


def test_unknown_filters_are_ignored(client):
    data = client.get("/api/dashboard?region=Atlantis&nonsense=1").get_json()
    assert data["filters"] == {}
    assert data["kpis"]["records"] == 200000


def test_chart_ignores_its_own_filter_and_marks_selection(client):
    bars = client.get("/api/dashboard?region=Europe").get_json()["charts"]["region_sales"]
    assert len(bars) == 7                       # other regions stay visible
    assert [b["label"] for b in bars if b["selected"]] == ["Europe"]


def test_selected_manufacturer_always_shown(client):
    data = client.get("/api/dashboard?manufacturer=VoltAutomotive").get_json()
    labels = [b["label"] for b in data["charts"]["manufacturer_sales"]]
    assert "VoltAutomotive" in labels


def test_empty_selection(client):
    q = "region=Europe&category=Electric Bus&year=2018&country=UK&battery=Solid-State"
    k = client.get(f"/api/dashboard?{q}").get_json()["kpis"]
    assert k["records"] == 0 and k["rating"] is None
