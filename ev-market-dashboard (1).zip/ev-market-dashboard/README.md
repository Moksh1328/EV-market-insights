# EV Market Performance

A Flask web app that turns two Tableau workbooks into a working website: an interactive dashboard and a data-driven market story, built from 200,000 electric-vehicle records.

![Dashboard](docs/dashboard.png)

## What's in it

**Dashboard (`/`)** rebuilds the Tableau "EV Executive Dashboard". Click any bar or map bubble to filter every chart, click again to clear, or use the dropdowns. Filters are kept in the URL, so any view can be shared as a link.

![Filtered view](docs/dashboard-filtered.png)

- Six KPIs: manufacturers, EV models, units sold, average rating, average range, average battery size
- A battery gauge showing what share of the whole market your current filters cover
- Seven charts: manufacturing-country map, sales by region, battery type, manufacturer and category, plus rating by manufacturer and range by category

**Market story (`/story`)** is a guided narrative. The numbers in the text are computed from the data when the page loads.

## Run it locally

You need Python 3.10 or newer.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000.

Run the tests with `pytest`.

## Put it online

GitHub stores the code, but **GitHub Pages can't run Flask**. Connect the repo to a host that runs Python instead:

- **Render, Railway, Fly.io:** build command `pip install -r requirements.txt`, start command `gunicorn app:app`. The included `Procfile` already says this.
- **PythonAnywhere:** upload or clone the repo and point a web app at `app.py`.

## Project layout

```
app.py              Flask routes and the JSON API
analytics.py        data loading, filtering and aggregation (pandas)
data/               ev_market.csv.gz  (200,000 rows x 11 columns, 4 MB)
templates/          base, dashboard and story pages
static/             CSS, JS, fonts, Chart.js, D3 and a world map (all bundled, no CDN)
scripts/            build_data.py  regenerates the data file from a .twbx
tests/              pytest suite
```

## API

| Endpoint | Description |
| --- | --- |
| `GET /api/dashboard` | KPIs and chart data. Filter with `year`, `region`, `category`, `battery`, `country`, `manufacturer`. Repeat a parameter for multi-select, e.g. `?region=Europe&region=Africa&battery=LFP` |
| `GET /api/story` | Aggregates behind the story page |
| `GET /healthz` | Liveness check |

## Rebuilding the data

`data/ev_market.csv.gz` holds only the columns the site uses, exported from the Tableau extract. To regenerate it from a workbook:

```bash
pip install -r requirements-dev.txt
python scripts/build_data.py path/to/EV_Market_Performance_Interactive_Refreshed.twbx
```

## About the data

The source table is named `ev_market_train`. Totals are almost identical across regions, years and countries, which suggests a generated or simulated dataset rather than real registrations. Treat the findings as a demonstration of the analysis, not as market facts.

## Credits

Chart.js (MIT), D3 and topojson-client (ISC), world-atlas (ISC, Natural Earth data), Bricolage Grotesque and IBM Plex Sans (SIL OFL). See `static/vendor/LICENSES.md`.
