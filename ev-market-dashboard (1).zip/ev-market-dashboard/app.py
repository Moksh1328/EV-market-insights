"""EV Market Performance -- Flask app.

Pages
  /        Interactive dashboard (click any bar or map bubble to cross-filter)
  /story   Market story: the same data told as a guided narrative

API
  /api/dashboard   Filtered KPIs and chart data (repeat a param for multi-select)
  /api/story       Aggregates behind the story page
  /healthz         Liveness check for hosting platforms
"""
from flask import Flask, jsonify, render_template, request

from analytics import DIMENSIONS, cached_dashboard, cached_story, get_store

app = Flask(__name__)
app.json.sort_keys = False

get_store()  # load the dataset once at startup so the first request is fast


@app.template_filter("compact")
def compact(value, digits=1):
    """1550703961 -> 1.55B, 174615722 -> 174.6M, 9400 -> 9.4K"""
    v = float(value)
    if abs(v) >= 1e9:
        return f"{v / 1e9:.2f}B"
    if abs(v) >= 1e6:
        return f"{v / 1e6:.{digits}f}M"
    if abs(v) >= 1e3:
        return f"{v / 1e3:.{digits}f}K"
    return f"{v:.0f}"


@app.template_filter("pct")
def pct(value, digits=1):
    """0.1126 -> 11.3%"""
    return f"{float(value) * 100:.{digits}f}%"


def parse_filters() -> dict:
    store = get_store()
    raw = {key: request.args.getlist(key) for key in DIMENSIONS}
    return store.clean_filters(raw)


@app.get("/")
def dashboard():
    store = get_store()
    return render_template(
        "dashboard.html",
        options=store.options,
        total_sales=store.total_sales,
        record_count=len(store.df),
    )


@app.get("/story")
def story():
    return render_template("story.html", s=cached_story())


@app.get("/api/dashboard")
def api_dashboard():
    filters = parse_filters()
    return jsonify(cached_dashboard(tuple(sorted(filters.items()))))


@app.get("/api/story")
def api_story():
    return jsonify(cached_story())


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


@app.after_request
def cache_headers(resp):
    # Static assets are vendored and versioned by deploy; let browsers keep them.
    if request.path.startswith("/static/"):
        resp.headers.setdefault("Cache-Control", "public, max-age=86400")
    return resp


if __name__ == "__main__":
    app.run(debug=True)
